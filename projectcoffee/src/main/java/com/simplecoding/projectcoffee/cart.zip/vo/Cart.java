package com.simplecoding.projectcoffee.cart.vo;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class Cart {
    private String puuid;     // 상품 UUID
    private String pName;     // 상품명
    private int price;        // 단가
    private int quantity;     // 수량
    private int lineTotal;    // price * quantity
}

