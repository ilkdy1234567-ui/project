package com.simplecoding.projectcoffee.cart.service;

import com.simplecoding.projectcoffee.cart.mapper.CartMapper;
import com.simplecoding.projectcoffee.cart.vo.Cart;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class CartService {
    private final CartMapper cartMapper;

    public CartService(CartMapper cartMapper) {
        this.cartMapper = cartMapper;
    }

    /** CU_NUMBER로 CART_ID 가져오고 없으면 생성 */
    @Transactional
    public long getOrCreateCartId(String cuNumber) {
        Long cartId = cartMapper.selectCartIdByCuNumber(cuNumber);
        if (cartId == null) {
            cartMapper.insertCart(cuNumber);
            cartId = cartMapper.selectCartIdByCuNumber(cuNumber);
        }
        return cartId;
    }

    /** 담기: 있으면 수량 증가, 없으면 insert */
    @Transactional
    public Map<String, Object> add(String cuNumber, String puuid, int quantity) {
        long cartId = getOrCreateCartId(cuNumber);
        if (quantity <= 0) quantity = 1;

        Integer current = null;
        try {
            current = cartMapper.selectCartItemQty(cartId, puuid);
        } catch (Exception ignored) {}

        if (current == null) {
            cartMapper.insertCartItem(cartId, puuid, quantity);
        } else {
            cartMapper.updateCartItemQty(cartId, puuid, current + quantity);
        }

        return getCartResponse(cartId);
    }

    /** 수량 변경: 0 이하면 삭제 */
    @Transactional
    public Map<String, Object> changeQty(String cuNumber, String puuid, int quantity) {
        long cartId = getOrCreateCartId(cuNumber);
        if (quantity <= 0) {
            cartMapper.deleteCartItem(cartId, puuid);
        } else {
            cartMapper.updateCartItemQty(cartId, puuid, quantity);
        }
        return getCartResponse(cartId);
    }

    /** 삭제 */
    @Transactional
    public Map<String, Object> remove(String cuNumber, String puuid) {
        long cartId = getOrCreateCartId(cuNumber);
        cartMapper.deleteCartItem(cartId, puuid);
        return getCartResponse(cartId);
    }

    /** 목록 조회 */
    @Transactional(readOnly = true)
    public Map<String, Object> items(String cuNumber) {
        Long cartId = cartMapper.selectCartIdByCuNumber(cuNumber);
        if (cartId == null) {
            // 장바구니가 아직 없으면 빈 응답
            Map<String, Object> empty = new HashMap<>();
            empty.put("items", Collections.emptyList());
            empty.put("count", 0);
            empty.put("total", 0);
            return empty;
        }
        return getCartResponse(cartId);
    }

    private Map<String, Object> getCartResponse(long cartId) {
        List<Cart> items = cartMapper.selectCartItems(cartId);
        int count = cartMapper.selectCartCount(cartId);
        int total = Optional.ofNullable(cartMapper.selectCartTotal(cartId)).orElse(0);

        Map<String, Object> res = new HashMap<>();
        res.put("items", items);
        res.put("count", count);
        res.put("total", total);
        return res;
    }
}