package com.simplecoding.projectcoffee.cart.controller;

import com.simplecoding.projectcoffee.cart.service.CartService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/cart")
public class CartController {
    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    /** 세션에 CU_NUMBER 없으면 생성해서 넣어줌 (쿠키 없이 세션) */
    private String getCuNumber(HttpSession session) {
        String cuNumber = (String) session.getAttribute("CU_NUMBER");

        if (cuNumber == null || cuNumber.isBlank()) {
            cuNumber = UUID.randomUUID().toString(); // 문자열 토큰 생성
            session.setAttribute("CU_NUMBER", cuNumber);
        }

        return cuNumber;
    }
    @GetMapping("/items")
    public Map<String, Object> items(HttpSession session) {
        String cuNumber = getCuNumber(session);
        return cartService.items(cuNumber);
    }

    @PostMapping("/add")
    public Map<String, Object> add(HttpSession session,
                                   @RequestParam String puuid,
                                   @RequestParam(defaultValue = "1") int quantity) {
        String cuNumber = getCuNumber(session);
        return cartService.add(cuNumber, puuid, quantity);
    }

    @PostMapping("/qty")
    public Map<String, Object> qty(HttpSession session,
                                   @RequestParam String puuid,
                                   @RequestParam int quantity) {
        String cuNumber = getCuNumber(session);
        return cartService.changeQty(cuNumber, puuid, quantity);
    }

    @PostMapping("/remove")
    public Map<String, Object> remove(HttpSession session,
                                      @RequestParam String puuid) {
        String cuNumber = getCuNumber(session);
        return cartService.remove(cuNumber, puuid);
    }
}