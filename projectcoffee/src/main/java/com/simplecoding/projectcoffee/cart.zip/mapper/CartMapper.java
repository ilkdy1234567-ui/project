package com.simplecoding.projectcoffee.cart.mapper;

import com.simplecoding.projectcoffee.cart.vo.Cart;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface CartMapper {
    Long selectCartIdByCuNumber(@Param("cuNumber") String cuNumber);

    int insertCart(@Param("cuNumber") String cuNumber);

    Integer selectCartItemQty(@Param("cartId") long cartId,
                              @Param("puuid") String puuid);

    int insertCartItem(@Param("cartId") long cartId,
                       @Param("puuid") String puuid,
                       @Param("quantity") int quantity);

    int updateCartItemQty(@Param("cartId") long cartId,
                          @Param("puuid") String puuid,
                          @Param("quantity") int quantity);

    int deleteCartItem(@Param("cartId") long cartId,
                       @Param("puuid") String puuid);

    List<Cart> selectCartItems(@Param("cartId") long cartId);

    int selectCartCount(@Param("cartId") long cartId);

    Integer selectCartTotal(@Param("cartId") long cartId);
}